const Registration = require('../models/Registration');

exports.registerForEvent = async (req, res) => {
  const { eventId, userId, customFieldValues } = req.body;

  try {
    const newRegistration = new Registration({ eventId, userId, customFieldValues });
    await newRegistration.save();
    res.status(201).json({ message: 'Registered successfully' });
  } catch (error) {
    res.status(400).json({ message: error.message });
  }
};
