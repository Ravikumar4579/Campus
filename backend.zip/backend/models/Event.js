const mongoose = require('mongoose');

const EventSchema = new mongoose.Schema({
  name: { type: String, required: true },
  date: { type: Date, required: true },
  venue: { type: String, required: true },
  teamSize: { type: Number, required: true },
  department: { type: String, required: true },
  customFields: [String], // To allow custom fields
  qrCode: { type: String }, // Stores base64 image for QR code
  registeredStudents: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
});

const Event = mongoose.model('Event', EventSchema);
module.exports = Event;
