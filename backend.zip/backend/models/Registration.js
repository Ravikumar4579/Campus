const mongoose = require('mongoose');

const registrationSchema = new mongoose.Schema({
  eventId: { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true },
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  customFieldValues: { type: Map, of: String }, // Store custom fields and their values
});

const Registration = mongoose.model('Registration', registrationSchema);
module.exports = Registration;
