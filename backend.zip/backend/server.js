// Import necessary modules and models at the top
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
const mongoURI = 'mongodb://localhost:27017/campus'; // Ensure the database name is 'campus'
mongoose.connect(mongoURI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

// Handle connection events
const db = mongoose.connection;

db.on('error', (error) => {
  console.error('MongoDB connection error:', error);
});

db.once('open', () => {
  console.log('✅ MongoDB connected successfully.');
});

// Define Mongoose Schemas and Models
const EventSchema = new mongoose.Schema({
  name: { type: String, required: true },
  date: { type: Date, required: true },
  venue: { type: String, required: true },
  teamSize: { type: Number, required: true },
  department: { type: String, required: true },
  customFields: [String],
  qrCode: String,
});

const RegistrationSchema = new mongoose.Schema({
  eventId: { type: mongoose.Schema.Types.ObjectId, ref: 'Event', required: true },
  registrationData: Object,
});

const Event = mongoose.model('Event', EventSchema);
const Registration = mongoose.model('Registration', RegistrationSchema);

// API Endpoints

// Login route (mock implementation)
app.post('/api/users/login', (req, res) => {
  const { email } = req.body;
  const role = email === 'admin@example.com' ? 'admin' : 'student';
  res.json({ token: 'dummy-token', role });
});

// Get all events
app.get('/api/events', async (req, res) => {
  try {
    const events = await Event.find({});
    res.json(events);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// **POST /api/events - Create a new event**
app.post('/api/events', async (req, res) => {
  const { name, date, venue, teamSize, department, customFields, qrCode } = req.body;

  // Input validation
  if (!name || !date || !venue || !teamSize || !department) {
    return res.status(400).json({ message: 'Please provide all required fields.' });
  }

  const event = new Event({
    name,
    date,
    venue,
    teamSize,
    department,
    customFields,
    qrCode,
  });

  try {
    const newEvent = await event.save();
    res.status(201).json(newEvent);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Delete event
app.delete('/api/events/:id', async (req, res) => {
  try {
    await Event.findByIdAndDelete(req.params.id);
    res.json({ message: 'Event deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// Register for an event
app.post('/api/events/:id/register', async (req, res) => {
  try {
    const registration = new Registration({
      eventId: req.params.id,
      registrationData: req.body,
    });
    const savedRegistration = await registration.save();
    res.json(savedRegistration);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
});