import React, { useState, useEffect } from 'react';
import './App.css';
import { CalendarDays, Users } from 'lucide-react';
import logo from './logo.png';

function App() {
  // State variables
  const [stats, setStats] = useState({
    events: 487,
    students: 9876,
  });
  const [menuOpen, setMenuOpen] = useState(false);
  const [loggedIn, setLoggedIn] = useState(false);
  const [role, setRole] = useState(''); // 'admin' or 'student'
  const [events, setEvents] = useState([]);
  const [newEvent, setNewEvent] = useState({ name: '', date: '', venue: '', teamSize: '', department: '', qrCode: '' });

  const [selectedDepartment, setSelectedDepartment] = useState(''); // Track selected department filter
  const [additionalFields, setAdditionalFields] = useState([]);
  const [createEventMode, setCreateEventMode] = useState(false); // Controls when to show event creation form
  const [editingEventId, setEditingEventId] = useState(null); // Track editing event
  const [selectedEvent, setSelectedEvent] = useState(null); // Event for registration
  const [registrationData, setRegistrationData] = useState({}); // Store registration form data
  const [deleteEventId, setDeleteEventId] = useState(null); // Track event to be deleted
  const [showQrCode, setShowQrCode] = useState(false); // Track QR code visibility

  const [showStudentLogin, setShowStudentLogin] = useState(false);
  const [showAdminLogin, setShowAdminLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  // Fetch events from the backend on mount
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const response = await fetch('/api/events');
        const data = await response.json();
        setEvents(data);
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };
    fetchEvents();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        events: prev.events + Math.floor(Math.random() * 2),
        students: prev.students + Math.floor(Math.random() * 3),
      }));
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const toggleMenu = () => {
    setMenuOpen(!menuOpen);
  };

  const handleLoginSubmit = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/users/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, password }),
      });
      const result = await response.json();
      if (result.token) {
        setRole(result.role);
        setLoggedIn(true);
        setShowStudentLogin(false);
        setShowAdminLogin(false);
      } else {
        alert('Login failed');
      }
    } catch (error) {
      console.error('Login error:', error);
    }
  };

  const handleLogout = () => {
    setLoggedIn(false);
    setRole('');
  };

  const handleNewEventChange = (e) => {
    const { name, value, files } = e.target;
    if (name === 'qrCode') {
      const file = files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setNewEvent({ ...newEvent, qrCode: reader.result });
      };
      reader.readAsDataURL(file);
    } else {
      setNewEvent({ ...newEvent, [name]: value });
    }
  };

  const createNewEvent = async () => {
    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newEvent),
      });
      const result = await response.json();
      if (response.status === 201) {
        setEvents([...events, result]);
        setNewEvent({ name: '', date: '', venue: '', teamSize: '', department: '', qrCode: '' });
        setAdditionalFields([]);
        setCreateEventMode(false);
      } else {
        alert(result.message);
      }
    } catch (error) {
      console.error('Error creating event:', error);
    }
  };

  const saveEventChanges = async () => {
    try {
      const response = await fetch(`/api/events/${editingEventId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(newEvent),
      });
      if (response.ok) {
        setEvents(events.map((event) =>
          event.id === editingEventId
            ? { ...newEvent, id: editingEventId, customFields: additionalFields.map(field => field.name) }
            : event
        ));
        setNewEvent({ name: '', date: '', venue: '', teamSize: '', department: '', qrCode: '' });
        setAdditionalFields([]);
        setEditingEventId(null);
        setCreateEventMode(false);
      }
    } catch (error) {
      console.error('Error saving event changes:', error);
    }
  };

  const handleAddField = () => {
    setAdditionalFields([...additionalFields, { name: '' }]);
  };

  const handleAdditionalFieldChange = (index, e) => {
    const newFields = [...additionalFields];
    newFields[index][e.target.name] = e.target.value;
    setAdditionalFields(newFields);
  };

  const handleEditEvent = (event) => {
    setNewEvent({ ...event });
    setAdditionalFields(event.customFields.map(name => ({ name })));
    setEditingEventId(event.id);
    setCreateEventMode(true);
  };

  const handleDeleteEvent = (eventId) => {
    setDeleteEventId(eventId);
  };

  const confirmDeleteEvent = async () => {
    try {
      const response = await fetch(`/api/events/${deleteEventId}`, {
        method: 'DELETE',
      });
      if (response.ok) {
        setEvents(events.filter(event => event.id !== deleteEventId));
        setDeleteEventId(null);
      } else {
        alert('Error deleting event');
      }
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  };

  const handleRegisterClick = (event) => {
    setSelectedEvent(event);
  };

  const handleRegistrationChange = (e, fieldName) => {
    setRegistrationData({ ...registrationData, [fieldName]: e.target.value });
  };

  const handleSubmitRegistration = async () => {
    try {
      const response = await fetch(`/api/events/${selectedEvent.id}/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(registrationData),
      });
      const result = await response.json();
      if (response.ok) {
        alert('Registration Successful');
        setSelectedEvent(null);
      } else {
        alert('Registration failed');
      }
    } catch (error) {
      console.error('Error registering for event:', error);
    }
  };

  const handleCancelEventCreation = () => {
    setCreateEventMode(false);
    setEditingEventId(null);
    setNewEvent({ name: '', date: '', venue: '', teamSize: '', department: '', qrCode: '' });
    setAdditionalFields([]);
  };

  const handleStudentLoginClick = () => {
    setShowStudentLogin(true);
    setShowAdminLogin(false);
  };

  const handleAdminLoginClick = () => {
    setShowAdminLogin(true);
    setShowStudentLogin(false);
  };

  const handlePayClick = () => {
    setShowQrCode(true);
  };

  // Filter events based on department
  const filteredEvents = selectedDepartment
    ? events.filter((event) => event.department === selectedDepartment)
    : events;

  return (
    <div className="app">
      <header className="header">
        <div className="logo">
          <img src={logo} alt="Logo" />
        </div>

        {loggedIn ? (
          <div className="nav-links">
            <div className="nav-item">
              <CalendarDays size={20} />
              <span>Events</span>
            </div>
            {role === 'admin' && (
              <div className="nav-item">
                <Users size={20} />
                <span onClick={() => setCreateEventMode(true)}>Create Event</span>
              </div>
            )}
            <button className="logout-btn" onClick={handleLogout}>
              Logout
            </button>
          </div>
        ) : (
          <div className="login-buttons">
            <button className="login-btn" onClick={handleAdminLoginClick}>
              Admin Login
            </button>
            <button className="login-btn" onClick={handleStudentLoginClick}>
              Student Login
            </button>
          </div>
        )}

        <div className="hamburger-menu" onClick={toggleMenu}>
          ☰
        </div>
      </header>

      {menuOpen && (
        <div className="mobile-menu">
          <button className="close-btn" onClick={toggleMenu}>
            X
          </button>
          {loggedIn ? (
            <>
              <div className="nav-item">
                <CalendarDays size={20} />
                <span>Events</span>
              </div>
              {role === 'admin' && (
                <div className="nav-item">
                  <Users size={20} />
                  <span onClick={() => setCreateEventMode(true)}>Create Event</span>
                </div>
              )}
              <div className="nav-item">
                <button className="logout-btn" onClick={handleLogout}>
                  Logout
                </button>
              </div>
            </>
          ) : (
            <>
              <button className="login-btn" onClick={handleAdminLoginClick}>
                Admin Login
              </button>
              <button className="login-btn" onClick={handleStudentLoginClick}>
                Student Login
              </button>
            </>
          )}
        </div>
      )}

      <main className="hero">
        <div className="hero-content">
          {loggedIn ? (
            <>
              <h1>Welcome, {role === 'admin' ? 'Admin' : 'Student'}</h1>

              {role === 'student' && (
                <div className="filter-department">
                  <label htmlFor="department">Filter by Department:</label>
                  <select
                    id="department"
                    value={selectedDepartment}
                    onChange={(e) => setSelectedDepartment(e.target.value)}
                  >
                    <option value="">All Departments</option>
                    <option value="CSE">CSE</option>
                    <option value="IT">IT</option>
                    <option value="Civil">Civil</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="ECE">ECE</option>
                  </select>
                </div>
              )}

              <div className="events-list">
                <h2>Available Events</h2>
                <div className="event-cards">
                  {filteredEvents.map((event) => (
                    <div key={event.id} className="event-card">
                      <h3>{event.name}</h3>
                      <p>Date: {event.date}</p>
                      <p>Venue: {event.venue}</p>
                      <p>Team Size: {event.teamSize}</p>
                      <p>Department: {event.department}</p>
                      {role === 'admin' && (
                        <>
                          <button className="edit-btn" onClick={() => handleEditEvent(event)}>
                            Edit
                          </button>
                          <button className="delete-btn" onClick={() => handleDeleteEvent(event.id)}>
                            Delete
                          </button>
                        </>
                      )}
                      {role === 'student' && (
                        <button className="register-btn" onClick={() => handleRegisterClick(event)}>
                          Register
                        </button>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {role === 'admin' && createEventMode && (
                <div className="create-event-modal">
                  <div className="create-event-card">
                    <h2>{editingEventId ? 'Edit Event' : 'Create New Event'}</h2>
                    <div className="scrollable-container">
                      <input
                        type="text"
                        name="name"
                        placeholder="Event Name"
                        value={newEvent.name}
                        onChange={handleNewEventChange}
                        className="event-input"
                      />
                      <input
                        type="date"
                        name="date"
                        placeholder="Event Date"
                        value={newEvent.date}
                        onChange={handleNewEventChange}
                        className="event-input"
                      />
                      <input
                        type="text"
                        name="venue"
                        placeholder="Event Venue"
                        value={newEvent.venue}
                        onChange={handleNewEventChange}
                        className="event-input"
                      />
                      <input
                        type="number"
                        name="teamSize"
                        placeholder="Team Size"
                        value={newEvent.teamSize}
                        onChange={handleNewEventChange}
                        className="event-input"
                      />
                      <select
                        name="department"
                        value={newEvent.department}
                        onChange={handleNewEventChange}
                        className="event-input"
                      >
                        <option value="">Select Department</option>
                        <option value="CSE">CSE</option>
                        <option value="IT">IT</option>
                        <option value="Civil">Civil</option>
                        <option value="Mechanical">Mechanical</option>
                        <option value="ECE">ECE</option>
                      </select>
                      <input
                        type="file"
                        name="qrCode"
                        accept="image/*"
                        onChange={handleNewEventChange}
                        className="event-input"
                      />

                      {additionalFields.map((field, index) => (
                        <div key={index}>
                          <input
                            type="text"
                            name="name"
                            placeholder="Field Name"
                            value={field.name}
                            onChange={(e) => handleAdditionalFieldChange(index, e)}
                            className="event-input"
                          />
                        </div>
                      ))}
                    </div>
                    <button onClick={handleAddField} className="add-field-btn">
                      Add New Field
                    </button>
                    {editingEventId ? (
                      <button className="primary-btn" onClick={saveEventChanges}>
                        Save Changes
                      </button>
                    ) : (
                      <button className="primary-btn" onClick={createNewEvent}>
                        Create Event
                      </button>
                    )}
                    <button className="secondary-btn" onClick={handleCancelEventCreation}>
                      Cancel
                    </button>
                  </div>
                </div>
              )}
            </>
          ) : (
            <>
              <h1>
                Campus Events
                <br />
                Made Simple
              </h1>
              <p>Discover, participate, and manage all your campus events in one place.</p>

              <div className="cta-buttons">
                <button className="primary-btn">Browse Events</button>
              </div>

              <div className="stats">
                <div className="stat-item">
                  <h2>{stats.events}+</h2>
                  <p>Events Held</p>
                </div>
                <div className="stat-item">
                  <h2>{stats.students}+</h2>
                  <p>Students Registered</p>
                </div>
                <div className="stat-item">
                  <h2>10+</h2>
                  <p>Departments</p>
                </div>
              </div>
            </>
          )}
        </div>
      </main>

      {showStudentLogin && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setShowStudentLogin(false)}>&times;</span>
            <h2>Student Login</h2>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button onClick={handleLoginSubmit}>Sign In</button>
          </div>
        </div>
      )}

      {showAdminLogin && (
        <div className="modal">
          <div className="modal-content">
            <span className="close" onClick={() => setShowAdminLogin(false)}>&times;</span>
            <h2>Admin Login</h2>
            <input
              type="email"
              placeholder="Email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
            />
            <input
              type="password"
              placeholder="Password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
            />
            <button onClick={handleLoginSubmit}>Sign In</button>
          </div>
        </div>
      )}

      {/* Registration Form Modal */}
      {selectedEvent && role === 'student' && (
        <div className="registration-modal">
          <div className="registration-card">
            <h2>Register for {selectedEvent.name}</h2>
            {selectedEvent.customFields.map((field, index) => (
              <input
                key={index}
                type="text"
                placeholder={field}
                value={registrationData[field] || ''}
                onChange={(e) => handleRegistrationChange(e, field)}
                className="event-input"
              />
            ))}
            <button className="primary-btn" onClick={handleSubmitRegistration}>
              Submit Registration
            </button>
            <button className="secondary-btn" onClick={() => setSelectedEvent(null)}>
              Cancel
            </button>
            {selectedEvent.qrCode && (
              <button className="primary-btn" onClick={handlePayClick}>
                Pay
              </button>
            )}
          </div>
        </div>
      )}

      {/* QR Code Modal */}
      {showQrCode && selectedEvent && (
        <div className="modal-qr">
          <div className="modal-qr-content">
            <span className="close" onClick={() => setShowQrCode(false)}>&times;</span>
            <h2>Scan QR Code to Pay</h2>
            <img src={selectedEvent.qrCode} alt="QR Code" style={{ width: '100%' }} />
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {deleteEventId && (
        <div className="delete-modal">
          <div className="delete-card">
            <h2>Are you sure you want to delete this event?</h2>
            <button className="primary-btn" onClick={confirmDeleteEvent}>
              Yes
            </button>
            <button className="secondary-btn" onClick={() => setDeleteEventId(null)}>
              No
            </button>
          </div>
        </div>
      )}

      <footer className="footer">
        <p>2024 Event Management System</p>
      </footer>
    </div>
  );
}

export default App;
